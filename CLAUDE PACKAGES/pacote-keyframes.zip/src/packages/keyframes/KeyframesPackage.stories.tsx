import { useEffect, useRef, useState } from 'react';
import type { Meta, StoryObj } from '@storybook/react';
import type { HelperAPI, RuntimeAPI } from '../core/types';
import { KeyframesPackage, keyframesDefaults, keyframesPresets } from './KeyframesPackage';
import type { KeyframesSpec } from './KeyframesPackage';
import { KeyframesRenderer } from './KeyframesRenderer';
import { keyframesRuntime } from './KeyframesRuntime';

const helpers = {} as HelperAPI;

function Preview({ spec }: { spec: KeyframesSpec }) {
  const ref = useRef<HTMLDivElement>(null);
  const [run, setRun] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el || run === 0) return undefined;
    let alive = true;
    const api: RuntimeAPI = {
      reduced: false,
      alive: () => alive,
      wait: (ms) => new Promise((r) => setTimeout(r, ms)),
      frame: (fn) => {
        const step = (ts: number) => {
          if (!alive) return;
          if (fn(ts) !== false) requestAnimationFrame(step);
        };
        step(performance.now());
      }
    };
    const inst = keyframesRuntime(el, spec, api);
    inst.play();
    return () => {
      alive = false;
    };
  }, [run, spec]);
  return (
    <div style={{ background: '#2A0E1A', padding: 24 }}>
      <style>{KeyframesPackage.css}</style>
      <button type="button" onClick={() => setRun((n) => n + 1)} style={{ marginBottom: 12 }}>
        Tocar animação
      </button>
      <div key={run} ref={ref} className="pk-keyframes">
        <KeyframesRenderer spec={spec} h={helpers} />
      </div>
    </div>
  );
}

const meta: Meta<typeof Preview> = {
  title: 'Packages/Keyframes',
  component: Preview,
  args: { spec: keyframesDefaults }
};

export default meta;

type Story = StoryObj<typeof Preview>;

export const Padrao: Story = {};

export const Surgir: Story = { args: { spec: { ...keyframesDefaults, ...keyframesPresets[0].spec } } };

export const Mover: Story = { args: { spec: { ...keyframesDefaults, ...keyframesPresets[1].spec } } };

export const Redimensionar: Story = { args: { spec: { ...keyframesDefaults, ...keyframesPresets[2].spec } } };

export const Quicar: Story = { args: { spec: { ...keyframesDefaults, ...keyframesPresets[3].spec } } };

export const Sequencia: Story = {
  args: { spec: { ...keyframesDefaults, ...keyframesPresets[4].spec, guides: true } }
};

export const Pulso: Story = { args: { spec: { ...keyframesDefaults, ...keyframesPresets[5].spec } } };
