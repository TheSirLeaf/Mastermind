import { createElement } from 'react';
import type { HelperAPI, PackageDef, PackageSpec, Preset } from '../core/types';
import { KeyframesRenderer } from './KeyframesRenderer';
import { keyframesRuntime } from './KeyframesRuntime';
import { keyframesForm } from './formSchema';
import { keyframesCss } from './keyframes.css';

export type KeyframeProp = 'x' | 'y' | 'w' | 'h' | 'opacity' | 'rotate' | 'scale';

export type KeyframeEase =
  | 'default'
  | 'linear'
  | 'ease'
  | 'ease-in'
  | 'ease-out'
  | 'ease-in-out'
  | 'back'
  | 'bounce'
  | 'elastic'
  | 'steps'
  | 'custom';

export interface KeyframeStep {
  t: number;
  prop: KeyframeProp;
  value: number;
  ease: KeyframeEase;
}

export interface KeyframesSpec extends PackageSpec {
  kind: 'shape' | 'text' | 'image';
  shape: 'rect' | 'pill' | 'circle';
  label: string;
  src: string;
  fill: string;
  color: string;
  fontSize: number;
  radius: number;
  border: boolean;
  w: number;
  stageH: number;
  frame: boolean;
  guides: boolean;
  x0: number;
  y0: number;
  w0: number;
  h0: number;
  o0: number;
  r0: number;
  s0: number;
  keys: KeyframeStep[];
  easing: Exclude<KeyframeEase, 'default'>;
  bz1: number;
  bz2: number;
  bz3: number;
  bz4: number;
  steps: number;
  startDelay: number;
  repeat: 'once' | 'loop' | 'pingpong';
}

export const keyframesDefaults: KeyframesSpec = {
  kind: 'shape',
  shape: 'rect',
  label: 'Elemento',
  src: '',
  fill: '#D6A84F',
  color: '#2A0E1A',
  fontSize: 32,
  radius: 22,
  border: false,
  w: 900,
  stageH: 420,
  frame: true,
  guides: false,
  x0: 340,
  y0: 220,
  w0: 220,
  h0: 120,
  o0: 0,
  r0: 0,
  s0: 1,
  keys: [
    { t: 700, prop: 'opacity', value: 1, ease: 'ease-out' },
    { t: 700, prop: 'y', value: 150, ease: 'ease-out' }
  ],
  easing: 'ease-in-out',
  bz1: 0.42,
  bz2: 0,
  bz3: 0.58,
  bz4: 1,
  steps: 4,
  startDelay: 400,
  repeat: 'once'
};

export const keyframesPresets: Preset<KeyframesSpec>[] = [
  {
    name: 'Surgir · fade e subida',
    desc: 'O elemento aparece subindo de leve',
    spec: {}
  },
  {
    name: 'Mover · A para B',
    desc: 'Desliza da esquerda para a direita',
    spec: {
      shape: 'pill',
      label: 'Deploy',
      o0: 1,
      x0: 40,
      y0: 150,
      keys: [{ t: 1400, prop: 'x', value: 640, ease: 'ease-in-out' }]
    }
  },
  {
    name: 'Redimensionar · crescer',
    desc: 'Cresce a partir do centro com leve estouro',
    spec: {
      shape: 'circle',
      label: '',
      fill: '#C95C62',
      o0: 1,
      x0: 400,
      y0: 160,
      w0: 100,
      h0: 100,
      keys: [
        { t: 1000, prop: 'w', value: 300, ease: 'back' },
        { t: 1000, prop: 'h', value: 300, ease: 'back' },
        { t: 1000, prop: 'x', value: 300, ease: 'back' },
        { t: 1000, prop: 'y', value: 60, ease: 'back' }
      ]
    }
  },
  {
    name: 'Quicar · queda',
    desc: 'Cai e quica no chão do palco',
    spec: {
      shape: 'circle',
      label: '',
      fill: '#72A68A',
      o0: 1,
      x0: 400,
      y0: 10,
      w0: 100,
      h0: 100,
      keys: [{ t: 1200, prop: 'y', value: 300, ease: 'bounce' }]
    }
  },
  {
    name: 'Sequência · entrar, girar, sair',
    desc: 'Vários keyframes encadeados',
    spec: {
      label: 'Build',
      x0: 40,
      y0: 150,
      keys: [
        { t: 500, prop: 'opacity', value: 1, ease: 'ease-out' },
        { t: 1700, prop: 'x', value: 640, ease: 'ease-in-out' },
        { t: 1700, prop: 'rotate', value: 360, ease: 'ease-in-out' },
        { t: 2300, prop: 'scale', value: 1.3, ease: 'back' },
        { t: 3000, prop: 'opacity', value: 0, ease: 'ease-in' }
      ]
    }
  },
  {
    name: 'Pulso · em loop',
    desc: 'Pulsa continuamente, ida e volta',
    spec: {
      label: 'Ao vivo',
      shape: 'pill',
      o0: 1,
      x0: 340,
      y0: 150,
      repeat: 'pingpong',
      keys: [
        { t: 700, prop: 'scale', value: 1.25, ease: 'ease-in-out' },
        { t: 700, prop: 'opacity', value: 0.7, ease: 'ease-in-out' }
      ]
    }
  }
];

export const KeyframesPackage: PackageDef<KeyframesSpec> = {
  id: 'keyframes',
  name: 'Keyframes',
  version: '1.0.0',
  icon: 'sparkles',
  author: 'Dialcron',
  description:
    'Elemento animado por keyframes: surge com fade, move-se entre posições e redimensiona, com o modo de animação escolhido e keyframes definidos por tempo, propriedade e valor.',
  defaults: keyframesDefaults,
  presets: keyframesPresets,
  box: { w: 900 },
  form: keyframesForm,
  css: keyframesCss,
  render: (spec: KeyframesSpec, h: HelperAPI) => createElement(KeyframesRenderer, { spec, h }),
  duration: (spec: KeyframesSpec) => {
    let total = 0;
    (Array.isArray(spec.keys) ? spec.keys : []).forEach((k) => {
      const t = Number(k && k.t);
      if (isFinite(t) && t > total) total = t;
    });
    const cycle = spec.repeat === 'pingpong' ? total * 2 : total;
    const delay = Number(spec.startDelay);
    return (isFinite(delay) ? Math.max(0, delay) : 0) + cycle;
  },
  runtime: keyframesRuntime
};
