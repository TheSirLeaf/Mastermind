import type { CSSProperties } from 'react';
import type { HelperAPI } from '../core/types';
import type { KeyframesSpec } from './KeyframesPackage';

interface KeyframesRendererProps {
  spec: KeyframesSpec;
  h: HelperAPI;
}

interface Pose {
  x: number;
  y: number;
  w: number;
  h: number;
  opacity: number;
  rotate: number;
  scale: number;
}

const PROPS: (keyof Pose)[] = ['x', 'y', 'w', 'h', 'opacity', 'rotate', 'scale'];

function num(v: unknown, d: number): number {
  const n = Number(v);
  return isFinite(n) ? n : d;
}

function baseOf(spec: KeyframesSpec): Pose {
  return {
    x: num(spec.x0, 0),
    y: num(spec.y0, 0),
    w: num(spec.w0, 200),
    h: num(spec.h0, 120),
    opacity: num(spec.o0, 1),
    rotate: num(spec.r0, 0),
    scale: num(spec.s0, 1)
  };
}

function poseAt(spec: KeyframesSpec, t: number): Pose {
  const base = baseOf(spec);
  const out = { ...base };
  const keys = Array.isArray(spec.keys) ? spec.keys : [];
  PROPS.forEach((p) => {
    const pts = keys
      .filter((k) => k && k.prop === p)
      .map((k) => ({ t: Math.max(0, num(k.t, 0)), v: num(k.value, base[p]) }))
      .sort((a, b) => a.t - b.t);
    if (!pts.length || pts[0].t > 0) pts.unshift({ t: 0, v: base[p] });
    let v = pts[pts.length - 1].v;
    for (let i = 0; i < pts.length; i++) {
      if (t <= pts[i].t) {
        if (i === 0 || pts[i].t === pts[i - 1].t) v = pts[i].v;
        else v = pts[i - 1].v + ((pts[i].v - pts[i - 1].v) * (t - pts[i - 1].t)) / (pts[i].t - pts[i - 1].t);
        break;
      }
    }
    out[p] = v;
  });
  return out;
}

function transformOf(p: Pose): string {
  return 'translate(' + p.x + 'px,' + p.y + 'px) rotate(' + p.rotate + 'deg) scale(' + p.scale + ')';
}

function timesOf(spec: KeyframesSpec): number[] {
  const set: Record<number, true> = { 0: true };
  (Array.isArray(spec.keys) ? spec.keys : []).forEach((k) => {
    if (k) set[Math.max(0, num(k.t, 0))] = true;
  });
  return Object.keys(set)
    .map(Number)
    .sort((a, b) => a - b);
}

export function KeyframesRenderer({ spec }: KeyframesRendererProps) {
  const first = poseAt(spec, 0);
  const last = poseAt(spec, Infinity);
  const radius = spec.shape === 'circle' ? '50%' : spec.shape === 'pill' ? '999px' : num(spec.radius, 22) + 'px';
  const actorStyle = {
    width: Math.max(0, first.w),
    height: Math.max(0, first.h),
    opacity: first.opacity,
    transform: transformOf(first),
    fontSize: num(spec.fontSize, 32),
    color: spec.color,
    '--kf-lw': Math.max(0, last.w) + 'px',
    '--kf-lh': Math.max(0, last.h) + 'px',
    '--kf-lt': transformOf(last),
    '--kf-lo': String(last.opacity)
  } as CSSProperties;
  if (spec.kind === 'shape') {
    actorStyle.background = spec.fill;
    actorStyle.borderRadius = radius;
  }
  const stageW = num(spec.w, 900);
  const stageH = num(spec.stageH, 420);
  const times = timesOf(spec);
  const poses = times.map((t) => ({ t, p: poseAt(spec, t) }));
  const centers = poses.map(({ p }) => [p.x + p.w / 2, p.y + p.h / 2]);

  let body;
  if (spec.kind === 'image') {
    body = spec.src ? <img src={spec.src} alt={spec.label} draggable={false} /> : <div className="kf-ph">imagem</div>;
  } else {
    body = spec.label;
  }

  return (
    <div className="kf-stage" data-frame={spec.frame ? 'true' : 'false'} style={{ width: stageW, height: stageH }}>
      {spec.guides ? (
        <svg className="kf-guides" width={stageW} height={stageH} viewBox={'0 0 ' + stageW + ' ' + stageH}>
          <polyline
            points={centers.map((c) => c[0] + ',' + c[1]).join(' ')}
            fill="none"
            stroke="#F7D98B"
            strokeWidth={2}
            strokeDasharray="8 6"
            opacity={0.7}
          />
          {poses.map(({ t, p }, i) => (
            <g key={t}>
              <rect
                x={centers[i][0] - (p.w * p.scale) / 2}
                y={centers[i][1] - (p.h * p.scale) / 2}
                width={Math.max(0, p.w * p.scale)}
                height={Math.max(0, p.h * p.scale)}
                transform={'rotate(' + p.rotate + ' ' + centers[i][0] + ' ' + centers[i][1] + ')'}
                fill="none"
                stroke="#F7D98B"
                strokeWidth={1.5}
                strokeDasharray="5 5"
                opacity={0.55}
              />
              <circle cx={centers[i][0]} cy={centers[i][1]} r={5} fill="#F7D98B" />
              <text x={centers[i][0] + 9} y={centers[i][1] - 9}>
                {t + ' ms'}
              </text>
            </g>
          ))}
        </svg>
      ) : null}
      <div
        className="kf-actor"
        data-kind={spec.kind}
        data-border={spec.kind === 'shape' && spec.border ? 'true' : 'false'}
        style={actorStyle}
      >
        {body}
      </div>
    </div>
  );
}
