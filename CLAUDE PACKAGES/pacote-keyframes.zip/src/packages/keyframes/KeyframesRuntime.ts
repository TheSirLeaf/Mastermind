import type { RuntimeAPI } from '../core/types';
import type { KeyframesSpec } from './KeyframesPackage';

export function keyframesRuntime(root: HTMLElement, spec: KeyframesSpec, api: RuntimeAPI) {
  const actor = root.querySelector<HTMLElement>('.kf-actor');
  if (!actor) {
    return { play: () => undefined, final: () => undefined };
  }
  const guides = root.querySelector<HTMLElement>('.kf-guides');
  const names = ['x', 'y', 'w', 'h', 'opacity', 'rotate', 'scale'];
  const num = (v: unknown, d: number) => {
    const n = Number(v);
    return isFinite(n) ? n : d;
  };
  const base: Record<string, number> = {
    x: num(spec.x0, 0),
    y: num(spec.y0, 0),
    w: num(spec.w0, 200),
    h: num(spec.h0, 120),
    opacity: num(spec.o0, 1),
    rotate: num(spec.r0, 0),
    scale: num(spec.s0, 1)
  };
  const tracks: Record<string, { t: number; v: number; e: string }[]> = {};
  names.forEach((n) => {
    tracks[n] = [];
  });
  const keys = Array.isArray(spec.keys) ? spec.keys : [];
  keys.forEach((k) => {
    if (!k || names.indexOf(k.prop) < 0) return;
    const e = !k.ease || k.ease === 'default' ? String(spec.easing || 'ease-in-out') : k.ease;
    tracks[k.prop].push({ t: Math.max(0, num(k.t, 0)), v: num(k.value, base[k.prop]), e });
  });
  let total = 0;
  names.forEach((n) => {
    const tr = tracks[n];
    tr.sort((a, b) => a.t - b.t);
    if (!tr.length || tr[0].t > 0) tr.unshift({ t: 0, v: base[n], e: 'linear' });
    total = Math.max(total, tr[tr.length - 1].t);
  });

  const bez = (x1: number, y1: number, x2: number, y2: number, x: number) => {
    if (x <= 0) return 0;
    if (x >= 1) return 1;
    const cx = 3 * x1;
    const bx = 3 * (x2 - x1) - cx;
    const ax = 1 - cx - bx;
    const cy = 3 * y1;
    const by = 3 * (y2 - y1) - cy;
    const ay = 1 - cy - by;
    const px = (t: number) => ((ax * t + bx) * t + cx) * t;
    let t = x;
    for (let i = 0; i < 8; i++) {
      const f = px(t) - x;
      if (Math.abs(f) < 1e-6) break;
      const d = (3 * ax * t + 2 * bx) * t + cx;
      if (Math.abs(d) < 1e-6) break;
      t -= f / d;
    }
    if (!(t >= 0 && t <= 1) || Math.abs(px(t) - x) > 1e-4) {
      let lo = 0;
      let hi = 1;
      t = x;
      for (let i = 0; i < 24; i++) {
        if (px(t) < x) lo = t;
        else hi = t;
        t = (lo + hi) / 2;
      }
    }
    return ((ay * t + by) * t + cy) * t;
  };
  const bounce = (p: number) => {
    const n = 7.5625;
    const d = 2.75;
    if (p < 1 / d) return n * p * p;
    if (p < 2 / d) return n * (p -= 1.5 / d) * p + 0.75;
    if (p < 2.5 / d) return n * (p -= 2.25 / d) * p + 0.9375;
    return n * (p -= 2.625 / d) * p + 0.984375;
  };
  const ease = (name: string, p: number) => {
    if (p <= 0) return 0;
    if (p >= 1) return 1;
    switch (name) {
      case 'linear':
        return p;
      case 'ease':
        return bez(0.25, 0.1, 0.25, 1, p);
      case 'ease-in':
        return bez(0.42, 0, 1, 1, p);
      case 'ease-out':
        return bez(0, 0, 0.58, 1, p);
      case 'ease-in-out':
        return bez(0.42, 0, 0.58, 1, p);
      case 'back':
        return bez(0.34, 1.56, 0.64, 1, p);
      case 'bounce':
        return bounce(p);
      case 'elastic':
        return Math.pow(2, -10 * p) * Math.sin(((p * 10 - 0.75) * (2 * Math.PI)) / 3) + 1;
      case 'steps': {
        const n = Math.max(1, Math.round(num(spec.steps, 4)));
        return Math.floor(p * n) / n;
      }
      case 'custom':
        return bez(
          Math.min(1, Math.max(0, num(spec.bz1, 0.42))),
          num(spec.bz2, 0),
          Math.min(1, Math.max(0, num(spec.bz3, 0.58))),
          num(spec.bz4, 1),
          p
        );
      default:
        return bez(0.42, 0, 0.58, 1, p);
    }
  };
  const at = (name: string, t: number) => {
    const tr = tracks[name];
    if (t <= tr[0].t) return tr[0].v;
    for (let i = 1; i < tr.length; i++) {
      const a = tr[i - 1];
      const b = tr[i];
      if (t <= b.t) {
        if (b.t === a.t) return b.v;
        return a.v + (b.v - a.v) * ease(b.e, (t - a.t) / (b.t - a.t));
      }
    }
    return tr[tr.length - 1].v;
  };
  const apply = (t: number) => {
    const s = actor.style;
    s.width = Math.max(0, at('w', t)) + 'px';
    s.height = Math.max(0, at('h', t)) + 'px';
    s.opacity = String(Math.min(1, Math.max(0, at('opacity', t))));
    s.transform =
      'translate(' + at('x', t) + 'px,' + at('y', t) + 'px) rotate(' + at('rotate', t) + 'deg) scale(' + at('scale', t) + ')';
  };

  const play = () => {
    if (guides) guides.style.display = 'none';
    apply(0);
    const delay = Math.max(0, num(spec.startDelay, 0));
    const mode = spec.repeat;
    let t0 = -1;
    api.frame((ts) => {
      if (t0 < 0) t0 = ts;
      const t = ts - t0 - delay;
      if (t <= 0) {
        apply(0);
        return true;
      }
      if (total <= 0) {
        apply(0);
        return false;
      }
      if (mode === 'loop') {
        apply(t % total);
        return true;
      }
      if (mode === 'pingpong') {
        const c = t % (2 * total);
        apply(c <= total ? c : 2 * total - c);
        return true;
      }
      if (t >= total) {
        apply(total);
        return false;
      }
      apply(t);
      return true;
    });
  };
  const final = () => {
    if (guides) guides.style.display = 'none';
    apply(total);
  };
  return { play, final };
}
