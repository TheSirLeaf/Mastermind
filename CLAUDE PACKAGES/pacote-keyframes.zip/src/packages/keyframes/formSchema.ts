import type { FormSchema } from '../core/types';
import type { KeyframesSpec } from './KeyframesPackage';

const easeOptions: [string, string][] = [
  ['linear', 'Linear'],
  ['ease', 'Suave'],
  ['ease-in', 'Acelera (ease-in)'],
  ['ease-out', 'Desacelera (ease-out)'],
  ['ease-in-out', 'Acelera e desacelera'],
  ['back', 'Estouro (back)'],
  ['bounce', 'Quicar (bounce)'],
  ['elastic', 'Elástico'],
  ['steps', 'Em degraus'],
  ['custom', 'Cubic-bezier personalizado']
];

export const keyframesForm: FormSchema = [
  {
    group: 'Elemento',
    icon: 'square',
    open: true,
    fields: [
      {
        k: 'kind',
        label: 'Tipo',
        type: 'seg',
        options: [
          ['shape', 'Forma', 'square'],
          ['text', 'Texto', 'bold'],
          ['image', 'Imagem', 'image']
        ]
      },
      { k: 'label', label: 'Texto', type: 'text', placeholder: 'Elemento', showIf: { k: 'kind', ne: 'image' } },
      { k: 'src', label: 'Endereço da imagem', type: 'text', placeholder: 'https://…', showIf: { k: 'kind', eq: 'image' } },
      {
        k: 'shape',
        label: 'Formato',
        type: 'seg',
        options: [
          ['rect', 'Retângulo', 'square'],
          ['pill', 'Pílula', 'dash'],
          ['circle', 'Círculo', 'circle']
        ],
        showIf: { k: 'kind', eq: 'shape' }
      },
      { k: 'radius', label: 'Arredondamento', type: 'range', min: 0, max: 80, step: 1, unit: 'px', showIf: { k: 'shape', eq: 'rect' } },
      {
        type: 'row',
        fields: [
          { k: 'fill', label: 'Cor de fundo', type: 'color', showIf: { k: 'kind', eq: 'shape' } },
          { k: 'color', label: 'Cor do texto', type: 'color', showIf: { k: 'kind', ne: 'image' } }
        ]
      },
      { k: 'fontSize', label: 'Tamanho do texto', type: 'range', min: 12, max: 140, step: 1, unit: 'px', showIf: { k: 'kind', ne: 'image' } },
      { k: 'border', label: 'Borda clara', type: 'toggle', showIf: { k: 'kind', eq: 'shape' } }
    ]
  },
  {
    group: 'Palco',
    icon: 'layers',
    open: false,
    fields: [
      {
        type: 'row',
        fields: [
          { k: 'w', label: 'Largura', type: 'number', min: 200, max: 1800, step: 10, unit: 'px' },
          { k: 'stageH', label: 'Altura', type: 'number', min: 120, max: 1000, step: 10, unit: 'px' }
        ]
      },
      { k: 'frame', label: 'Moldura tracejada ao redor do palco', type: 'toggle' },
      {
        k: 'guides',
        label: 'Mostrar trajetória e quadros-chave',
        type: 'toggle',
        help: 'Guia visual para editar. Some quando a animação toca.'
      }
    ]
  },
  {
    group: 'Estado inicial',
    icon: 'sliders',
    open: true,
    fields: [
      {
        type: 'info',
        text: 'Valores antes do primeiro keyframe. Posição em pixels, a partir do canto superior esquerdo do palco.'
      },
      {
        type: 'row',
        fields: [
          { k: 'x0', label: 'X', type: 'number', step: 5 },
          { k: 'y0', label: 'Y', type: 'number', step: 5 }
        ]
      },
      {
        type: 'row',
        fields: [
          { k: 'w0', label: 'Largura', type: 'number', min: 0, step: 5 },
          { k: 'h0', label: 'Altura', type: 'number', min: 0, step: 5 }
        ]
      },
      { k: 'o0', label: 'Opacidade', type: 'range', min: 0, max: 1, step: 0.05 },
      {
        type: 'row',
        fields: [
          { k: 'r0', label: 'Rotação', type: 'range', min: -360, max: 360, step: 5, unit: '°' },
          { k: 's0', label: 'Escala', type: 'range', min: 0.1, max: 3, step: 0.05, unit: '×' }
        ]
      }
    ]
  },
  {
    group: 'Keyframes',
    icon: 'clock',
    open: true,
    fields: [
      {
        type: 'info',
        text: 'Cada linha leva uma propriedade a um valor no tempo indicado. A suavização vale para o trecho que chega nesse keyframe.'
      },
      {
        k: 'keys',
        type: 'list',
        addLabel: 'Adicionar keyframe',
        itemDefault: { t: 1000, prop: 'x', value: 400, ease: 'default' },
        item: [
          { k: 't', type: 'number', min: 0, step: 50, w: '66px', label: 'Tempo (ms)' },
          {
            k: 'prop',
            type: 'select',
            w: '1.3fr',
            options: [
              ['x', 'X'],
              ['y', 'Y'],
              ['w', 'Largura'],
              ['h', 'Altura'],
              ['opacity', 'Opacidade'],
              ['rotate', 'Rotação'],
              ['scale', 'Escala']
            ]
          },
          { k: 'value', type: 'number', step: 0.1, w: '66px', label: 'Valor' },
          { k: 'ease', type: 'select', w: '1.4fr', options: [['default', 'Padrão'], ...easeOptions] }
        ]
      },
      {
        type: 'buttons',
        items: [
          {
            label: 'Ordenar por tempo',
            icon: 'swap',
            do: (spec: KeyframesSpec) => {
              spec.keys = spec.keys.slice().sort((a, b) => a.t - b.t);
            }
          },
          {
            label: 'Limpar',
            icon: 'x',
            do: (spec: KeyframesSpec) => {
              spec.keys = [];
            }
          }
        ]
      }
    ]
  },
  {
    group: 'Animação',
    icon: 'sparkles',
    open: true,
    fields: [
      { k: 'easing', label: 'Modo de animação', type: 'select', options: easeOptions },
      {
        type: 'row',
        fields: [
          { k: 'bz1', label: 'x1', type: 'number', min: 0, max: 1, step: 0.05 },
          { k: 'bz2', label: 'y1', type: 'number', step: 0.05 },
          { k: 'bz3', label: 'x2', type: 'number', min: 0, max: 1, step: 0.05 },
          { k: 'bz4', label: 'y2', type: 'number', step: 0.05 }
        ],
        showIf: { k: 'easing', eq: 'custom' }
      },
      { k: 'steps', label: 'Degraus', type: 'number', min: 1, max: 30, step: 1, showIf: { k: 'easing', eq: 'steps' } },
      { k: 'startDelay', label: 'Começar após', type: 'range', min: 0, max: 5000, step: 100, unit: ' ms' },
      {
        k: 'repeat',
        label: 'Repetição',
        type: 'seg',
        options: [
          ['once', 'Uma vez'],
          ['loop', 'Em loop'],
          ['pingpong', 'Ida e volta']
        ]
      }
    ]
  }
];
