export const keyframesCss = `
.pk-keyframes .kf-stage{position:relative;overflow:hidden;box-sizing:border-box}
.pk-keyframes .kf-stage[data-frame="true"]{border:2px dashed rgba(247,217,139,.35);border-radius:18px;background:rgba(255,248,245,.03)}
.pk-keyframes .kf-actor{position:absolute;left:0;top:0;box-sizing:border-box;transform-origin:50% 50%;display:flex;align-items:center;justify-content:center;overflow:hidden;will-change:transform,opacity,width,height;font-family:"DM Sans",system-ui,sans-serif;font-weight:700;line-height:1.1;text-align:center;white-space:nowrap}
.pk-keyframes .kf-actor[data-kind="shape"]{box-shadow:0 14px 34px rgba(0,0,0,.35)}
.pk-keyframes .kf-actor[data-kind="shape"][data-border="true"]{border:3px solid rgba(255,248,245,.4)}
.pk-keyframes .kf-actor[data-kind="text"]{overflow:visible}
.pk-keyframes .kf-actor[data-kind="image"]{overflow:hidden}
.pk-keyframes .kf-actor img{width:100%;height:100%;object-fit:contain;display:block}
.pk-keyframes .kf-ph{width:100%;height:100%;display:grid;place-items:center;background:rgba(255,248,245,.1);color:rgba(255,248,245,.6);font-size:18px}
.pk-keyframes .kf-guides{position:absolute;left:0;top:0;pointer-events:none;overflow:visible}
.pk-keyframes .kf-guides text{font:600 14px "DM Sans",system-ui,sans-serif;fill:#F7D98B}
@media (prefers-reduced-motion:reduce){
  .pk-keyframes .kf-actor{width:var(--kf-lw)!important;height:var(--kf-lh)!important;transform:var(--kf-lt)!important;opacity:var(--kf-lo)!important}
}
`;
